import 'package:intl/intl.dart';
import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';

import 'apex_models.dart';
import 'telemetry_engine.dart';

class DayRepository {
  DayRepository._(this._isar);

  final Isar _isar;

  static Future<DayRepository> open() async {
    final dir = await getApplicationDocumentsDirectory();
    final isar = await Isar.open(
      [DayEntrySchema],
      directory: dir.path,
      name: 'jee_apex_tracker',
    );
    return DayRepository._(isar);
  }

  Future<DayEntry> loadDay(String dateString, TargetProfile profile) async {
    final stored = await _isar.dayEntrys.getByDateString(dateString);
    if (stored != null) return stored;
    final day = createDefaultDay(dateString, profile);
    await saveDay(day);
    return day;
  }

  Future<void> saveDay(DayEntry day) async {
    await _isar.writeTxn(() async {
      await _isar.dayEntrys.put(day);
    });
  }

  Future<List<HistoricalPoint>> loadHistory({
    required DateTime anchorDate,
    required int days,
    required TargetProfile profile,
  }) async {
    final engine = TelemetryEngine();
    final formatter = DateFormat('yyyy-MM-dd');
    final start = anchorDate.subtract(Duration(days: days - 1));
    final points = <HistoricalPoint>[];

    for (var i = 0; i < days; i++) {
      final date = start.add(Duration(days: i));
      final dateString = formatter.format(date);
      final day = await _isar.dayEntrys.getByDateString(dateString);
      if (day == null) {
        points.add(
          HistoricalPoint(
            dateString: dateString,
            selection: 0,
            punctuality: 0,
            subjectHours: const {},
          ),
        );
      } else {
        final metrics = engine.calculate(day, profile);
        points.add(
          HistoricalPoint(
            dateString: dateString,
            selection: metrics.selection,
            punctuality: metrics.punctuality,
            subjectHours: _subjectHours(day),
          ),
        );
      }
    }
    return points;
  }

  Map<String, double> _subjectHours(DayEntry day) {
    final hours = <String, double>{};
    for (final task in day.tasks) {
      hours.update(
        task.subject,
        (value) => value + task.actualHours,
        ifAbsent: () => task.actualHours,
      );
    }
    return hours;
  }
}
