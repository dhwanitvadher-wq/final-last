# JEE Apex Tracker

Offline-first Flutter productivity and execution tracker for JEE preparation, tuned for Android phones such as the Redmi Note 5 Pro while remaining clean for Windows, macOS, and iOS later.

## What This Version Includes

- Lightweight `ChangeNotifier` + `AnimatedBuilder` state flow.
- Isar local database schema with date-keyed `YYYY-MM-DD` day entries.
- Dynamic target profiles: JEE, NEET, CA, and General.
- Five-stream telemetry engine:
  - Effort Index
  - Productivity Meter
  - Punctuality Meter with 24-hour backlog penalty
  - Revision Meter
  - Selection Probability with 70% ceiling cap when expired backlog exists
- Mobile unified vertical workspace for 5.99-inch Android screens.
- Desktop three-panel horizon layout for future Windows/macOS builds.
- Five concentric custom-painted progress rings.
- Daily micro-goals with completion, on-time state, actual hours, and swipe delete.
- Custom task injection.
- Backlog box with 24-hour countdown and expiry warning.
- Error Log Black Box with quick tags.
- 7-day trend graph and subject-hour allocation bar using `CustomPainter`.
- Fully offline: no login, no cloud, no server.

## Project Structure

```text
lib/
  main.dart
  core/
    apex_models.dart
    apex_controller.dart
    day_repository.dart
    telemetry_engine.dart
  theme/
    app_theme.dart
```

Older widget files may still exist from the first prototype, but the active app is driven by `lib/main.dart` and `lib/core`.

## Android Setup For Redmi Note 5 Pro

Install Flutter and Android Studio first:

- Flutter: https://docs.flutter.dev/get-started/install/windows
- Android Studio: https://developer.android.com/studio

Then run:

```bash
cd C:\Users\niles\Documents\Codex\2026-06-10\act-as-an-elite-full-stack\outputs\jee_apex_tracker
flutter create --platforms=android .
flutter pub get
dart run build_runner build --delete-conflicting-outputs
```

The build-runner command generates Isar's required `apex_models.g.dart` file.

## Android Gradle Settings

After `flutter create --platforms=android .`, open:

```text
android/app/build.gradle
```

Use these values:

```groovy
android {
    namespace "com.apex.tracker.jee_tracker"
    compileSdkVersion 36

    defaultConfig {
        applicationId "com.apex.tracker.jee_tracker"
        minSdkVersion 21
        targetSdkVersion 36
        versionCode 1
        versionName "1.0"
    }
}
```

If your installed Android SDK does not yet include API 36, either install API 36 in Android Studio SDK Manager or temporarily use your highest installed SDK.

## Build APK

For Redmi Note 5 Pro:

```bash
flutter build apk --release --target-platform android-arm64
```

APK output:

```text
build\app\outputs\flutter-apk\app-release.apk
```

Transfer that APK to your phone and install it. If Android blocks it, enable install permission for the app you used to open the APK:

```text
Settings > Security > Install unknown apps
```

## Run In Debug

Connect the phone with USB debugging enabled:

```bash
flutter devices
flutter run -d <device-id>
```

## Desktop Later

```bash
flutter create --platforms=windows,macos .
flutter run -d windows
flutter run -d macos
```
