import 'package:flutter/material.dart';

class AppColors {
  static const canvas = Color(0xFF0D1117);
  static const surface = Color(0xFF161B22);
  static const surfaceHigh = Color(0xFF1B2330);
  static const border = Color(0xFF30363D);
  static const text = Color(0xFFF0F6FC);
  static const muted = Color(0xFF8B949E);
  static const physics = Color(0xFF58A6FF);
  static const chemistry = Color(0xFF3FB950);
  static const mathematics = Color(0xFFFF7A00);
  static const analytics = Color(0xFFBC8CFF);
  static const selection = Color(0xFFFFD166);
  static const danger = Color(0xFFFF4D5E);

  static const midnight = canvas;
  static const deepGray = surface;
  static const panel = surface;
  static const panelElevated = surfaceHigh;
  static const line = border;
  static const warning = selection;
}

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.canvas,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.physics,
      secondary: AppColors.analytics,
      surface: AppColors.surface,
      error: AppColors.danger,
    ),
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
      headlineMedium: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
      titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
      titleMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
      bodyLarge: TextStyle(fontSize: 14, height: 1.35),
      bodyMedium: TextStyle(fontSize: 12, height: 1.35),
    ).apply(bodyColor: AppColors.text, displayColor: AppColors.text),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.canvas,
      hintStyle: const TextStyle(color: AppColors.muted),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.physics, width: 1.3),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.canvas,
      selectedColor: AppColors.analytics.withOpacity(0.24),
      side: const BorderSide(color: AppColors.border),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      labelStyle: const TextStyle(color: AppColors.text, fontSize: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.physics,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
  );
}
