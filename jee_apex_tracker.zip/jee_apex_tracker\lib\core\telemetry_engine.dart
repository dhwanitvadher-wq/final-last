import 'dart:math' as math;

import 'apex_models.dart';

class TelemetryEngine {
  TelemetrySnapshot calculate(DayEntry day, TargetProfile profile) {
    final totalTarget = day.tasks.fold<double>(
      0,
      (sum, task) => sum + task.targetHours,
    );
    final totalActual = day.tasks.fold<double>(
      0,
      (sum, task) => sum + task.actualHours,
    );
    final effort = totalTarget <= 0 ? 0.0 : (totalActual / totalTarget).clamp(0, 1);

    final completedTasks = day.tasks.where((task) => task.isCompleted).length;
    final completedBacklogs =
        day.backlogItems.where((item) => item.isCompleted).length;
    final activeBacklogs =
        day.backlogItems.where((item) => !item.isCompleted).length;
    final totalSet = math.max(1, day.tasks.length + activeBacklogs);
    final productivity =
        ((completedTasks + completedBacklogs) / totalSet).clamp(0, 1);

    final completedDailyTasks = day.tasks.where((task) => task.isCompleted).toList();
    final basePunctuality = completedDailyTasks.isEmpty
        ? 0.0
        : completedDailyTasks.where((task) => task.isOnTime).length /
            completedDailyTasks.length;
    final expiredBacklogs = day.backlogItems
        .where((item) => !item.isCompleted && _isExpired(item))
        .length;
    final punctuality =
        (basePunctuality - (expiredBacklogs * 0.15)).clamp(0, 1);

    final reviewTasks = day.tasks.where((task) {
      final title = task.title.toLowerCase();
      return task.subject == 'Analytics' ||
          title.contains('review') ||
          title.contains('error analysis');
    }).toList();
    final reviewCompletion = reviewTasks.isEmpty
        ? 0.0
        : reviewTasks.where((task) => task.isCompleted).length / reviewTasks.length;
    final errorLogBoost = (day.errorLogs.length * 0.06).clamp(0, 0.30);
    final revision = (reviewCompletion * 0.70 + errorLogBoost).clamp(0, 1);

    var selection = (productivity * profile.productivityWeight) +
        (punctuality * profile.punctualityWeight) +
        (effort * profile.effortWeight) +
        (revision * profile.revisionWeight);
    if (expiredBacklogs > 0) selection = math.min(selection, 0.70);

    return TelemetrySnapshot(
      effort: effort.toDouble(),
      productivity: productivity.toDouble(),
      punctuality: punctuality.toDouble(),
      revision: revision.toDouble(),
      selection: selection.clamp(0, 1).toDouble(),
      expiredBacklogCount: expiredBacklogs,
      totalActualHours: totalActual,
    );
  }

  String summary(DayEntry day, TargetProfile profile) {
    final metrics = calculate(day, profile);
    final effort = _percent(metrics.effort);
    final punctuality = _percent(metrics.punctuality);
    final selection = _percent(metrics.selection);

    if (metrics.expiredBacklogCount > 0) {
      return '${metrics.expiredBacklogCount} backlog item(s) crossed 24 hours, so ${profile.selectionLabel} is capped at $selection%. Clear aging gaps first.';
    }
    if (metrics.productivity >= 0.85 && metrics.punctuality >= 0.75) {
      return 'Elite execution: effort is $effort%, punctuality is $punctuality%, and ${profile.selectionLabel} is $selection%. Repeat this pattern tomorrow.';
    }
    if (metrics.effort >= 0.8 && metrics.punctuality < 0.55) {
      return 'Strong effort at $effort%, but punctuality fell to $punctuality%. Compress blocks and protect finish times tomorrow.';
    }
    if (metrics.revision < 0.35) {
      return 'Your revision depth is weak today. Add one error-analysis pass before ending the session.';
    }
    return 'Balanced progress: effort $effort%, punctuality $punctuality%, ${profile.selectionLabel} $selection%. Keep reducing backlog debt.';
  }

  bool _isExpired(BacklogItem item) {
    return DateTime.now().difference(item.originDate).inMinutes > 24 * 60;
  }

  int _percent(double value) => (value * 100).round();
}
