import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import 'apex_models.dart';
import 'day_repository.dart';
import 'telemetry_engine.dart';

class ApexController extends ChangeNotifier {
  ApexController(this._repository);

  final DayRepository _repository;
  final TelemetryEngine _engine = TelemetryEngine();
  final Uuid _uuid = const Uuid();

  DateTime selectedDate = DateTime.now();
  TargetProfile profile = TargetProfile.jee;
  DayEntry? day;
  TelemetrySnapshot? telemetry;
  List<HistoricalPoint> sevenDayHistory = [];
  List<HistoricalPoint> thirtyDayHistory = [];
  bool loading = true;

  Future<void> initialize() async {
    await loadDate(DateTime.now());
  }

  Future<void> loadDate(DateTime date) async {
    loading = true;
    selectedDate = date;
    notifyListeners();

    day = await _repository.loadDay(_dateKey(date), profile);
    profile = TargetProfile.fromLabel(day!.targetExam);
    telemetry = _engine.calculate(day!, profile);
    day!.dailySummaryText = _engine.summary(day!, profile);
    await _cacheHistory();

    loading = false;
    notifyListeners();
  }

  Future<void> changeProfile(TargetProfile next) async {
    final current = day;
    if (current == null) return;
    profile = next;
    current.targetExam = next.label;
    await _persist(current);
  }

  Future<void> updateTask(
    int index, {
    bool? completed,
    bool? onTime,
    double? actualHours,
    int? priority,
  }) async {
    final current = day;
    if (current == null) return;
    final task = current.tasks[index];
    if (completed != null) {
      task.isCompleted = completed;
      if (!completed) task.isOnTime = false;
    }
    if (onTime != null) task.isOnTime = onTime;
    if (actualHours != null) task.actualHours = actualHours;
    if (priority != null) task.priority = priority;
    await _persist(current);
  }

  Future<void> addCustomTask(String title, String subject, double hours) async {
    final current = day;
    if (current == null || title.trim().isEmpty) return;
    current.tasks.add(
      TaskItem()
        ..title = title.trim()
        ..subject = subject
        ..targetHours = hours
        ..actualHours = 0
        ..priority = 1,
    );
    await _persist(current);
  }

  Future<void> removeTask(int index) async {
    final current = day;
    if (current == null) return;
    current.tasks.removeAt(index);
    await _persist(current);
  }

  Future<void> addBacklog(String title) async {
    final current = day;
    if (current == null || title.trim().isEmpty) return;
    current.backlogItems.add(
      BacklogItem()
        ..uid = _uuid.v4()
        ..title = title.trim()
        ..originDate = DateTime.now()
        ..isCompleted = false,
    );
    await _persist(current);
  }

  Future<void> toggleBacklog(String uid) async {
    final current = day;
    if (current == null) return;
    final item = current.backlogItems.firstWhere((item) => item.uid == uid);
    item.isCompleted = !item.isCompleted;
    await _persist(current);
  }

  Future<void> addErrorLog(String description, List<String> tags) async {
    final current = day;
    if (current == null || description.trim().isEmpty) return;
    current.errorLogs.add(
      ErrorLogItem()
        ..description = description.trim()
        ..tags = tags
        ..timestamp = DateTime.now(),
    );
    await _persist(current);
  }

  Future<void> setMentalClarity(int value) async {
    final current = day;
    if (current == null) return;
    current.mentalClarity = value;
    await _persist(current);
  }

  Future<void> _persist(DayEntry current) async {
    telemetry = _engine.calculate(current, profile);
    current.dailySummaryText = _engine.summary(current, profile);
    await _repository.saveDay(current);
    await _cacheHistory();
    notifyListeners();
  }

  Future<void> _cacheHistory() async {
    sevenDayHistory = await _repository.loadHistory(
      anchorDate: selectedDate,
      days: 7,
      profile: profile,
    );
    thirtyDayHistory = await _repository.loadHistory(
      anchorDate: selectedDate,
      days: 30,
      profile: profile,
    );
  }

  String _dateKey(DateTime date) => DateFormat('yyyy-MM-dd').format(date);
}
