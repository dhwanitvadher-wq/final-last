import 'package:isar/isar.dart';

part 'apex_models.g.dart';

@collection
class DayEntry {
  Id id = Isar.autoIncrement;

  @Index(unique: true, replace: true)
  late String dateString;

  late String targetExam;
  List<TaskItem> tasks = [];
  List<BacklogItem> backlogItems = [];
  List<ErrorLogItem> errorLogs = [];
  int mentalClarity = 1;
  String dailySummaryText = '';
}

@embedded
class TaskItem {
  String title = '';
  String subject = 'Custom';
  double targetHours = 0;
  double actualHours = 0;
  bool isCompleted = false;
  bool isOnTime = false;
  int priority = 1;
}

@embedded
class BacklogItem {
  String uid = '';
  String title = '';
  DateTime originDate = DateTime.now();
  bool isCompleted = false;
}

@embedded
class ErrorLogItem {
  String description = '';
  List<String> tags = [];
  DateTime timestamp = DateTime.now();
}

enum TargetProfile {
  jee('JEE', 'JEE Selection Probability', 0.35, 0.35, 0.15, 0.15),
  neet('NEET', 'NEET Selection Probability', 0.32, 0.32, 0.16, 0.20),
  ca('CA', 'CA Selection Probability', 0.30, 0.38, 0.12, 0.20),
  general('General', 'Execution Probability', 0.34, 0.28, 0.18, 0.20);

  const TargetProfile(
    this.label,
    this.selectionLabel,
    this.productivityWeight,
    this.punctualityWeight,
    this.effortWeight,
    this.revisionWeight,
  );

  final String label;
  final String selectionLabel;
  final double productivityWeight;
  final double punctualityWeight;
  final double effortWeight;
  final double revisionWeight;

  static TargetProfile fromLabel(String label) {
    return TargetProfile.values.firstWhere(
      (profile) => profile.label == label,
      orElse: () => TargetProfile.jee,
    );
  }
}

class TelemetrySnapshot {
  const TelemetrySnapshot({
    required this.effort,
    required this.productivity,
    required this.punctuality,
    required this.revision,
    required this.selection,
    required this.expiredBacklogCount,
    required this.totalActualHours,
  });

  final double effort;
  final double productivity;
  final double punctuality;
  final double revision;
  final double selection;
  final int expiredBacklogCount;
  final double totalActualHours;
}

class HistoricalPoint {
  const HistoricalPoint({
    required this.dateString,
    required this.selection,
    required this.punctuality,
    required this.subjectHours,
  });

  final String dateString;
  final double selection;
  final double punctuality;
  final Map<String, double> subjectHours;
}

DayEntry createDefaultDay(String dateString, TargetProfile profile) {
  final day = DayEntry()
    ..dateString = dateString
    ..targetExam = profile.label
    ..mentalClarity = 1;

  day.tasks = [
    _task('Physics Deep Work', 'Physics', 2, 2),
    _task('Chemistry Deep Work', 'Chemistry', 2, 2),
    _task('Mathematics Deep Work', 'Mathematics', 2, 2),
    _task('Strategic Backlog Clearance', 'Analytics', 1.5, 2),
    _task('Master Error Analysis & Note Review', 'Analytics', 0.75, 2),
  ];
  return day;
}

TaskItem _task(String title, String subject, double hours, int priority) {
  return TaskItem()
    ..title = title
    ..subject = subject
    ..targetHours = hours
    ..actualHours = 0
    ..priority = priority;
}
