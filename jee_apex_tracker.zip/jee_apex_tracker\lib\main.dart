import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'core/apex_controller.dart';
import 'core/apex_models.dart';
import 'core/day_repository.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repository = await DayRepository.open();
  runApp(JeeApexTrackerApp(repository: repository));
}

class JeeApexTrackerApp extends StatelessWidget {
  const JeeApexTrackerApp({super.key, required this.repository});

  final DayRepository repository;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JEE Apex Tracker',
      theme: buildAppTheme(),
      home: ApexWorkspace(controller: ApexController(repository)..initialize()),
    );
  }
}

class ApexWorkspace extends StatelessWidget {
  const ApexWorkspace({super.key, required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final day = controller.day;
        final metrics = controller.telemetry;
        if (controller.loading || day == null || metrics == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        return Scaffold(
          resizeToAvoidBottomInset: true,
          body: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                if (constraints.maxWidth >= 920) {
                  return _DesktopHorizon(controller: controller);
                }
                return _MobilePipeline(controller: controller);
              },
            ),
          ),
          floatingActionButton: FloatingActionButton(
            backgroundColor: AppColors.analytics,
            foregroundColor: Colors.white,
            onPressed: () => _showAddTaskSheet(context, controller),
            child: const Icon(Icons.add_task),
          ),
        );
      },
    );
  }
}

class _MobilePipeline extends StatelessWidget {
  const _MobilePipeline({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    final day = controller.day!;
    return CustomScrollView(
      slivers: [
        SliverPersistentHeader(
          pinned: true,
          delegate: _DashboardDelegate(controller: controller, compact: true),
        ),
        SliverToBoxAdapter(child: _CalendarRibbon(controller: controller)),
        SliverToBoxAdapter(child: _SectionTitle('Daily Micro-Goals')),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) => _TaskTile(
              task: day.tasks[index],
              onDismissed: () => controller.removeTask(index),
              onCompleted: (value) =>
                  controller.updateTask(index, completed: value),
              onTime: (value) => controller.updateTask(index, onTime: value),
              onHours: (value) =>
                  controller.updateTask(index, actualHours: value),
            ),
            childCount: day.tasks.length,
          ),
        ),
        SliverToBoxAdapter(child: _BacklogBox(controller: controller)),
        SliverToBoxAdapter(child: _ErrorConsole(controller: controller)),
        SliverToBoxAdapter(child: _TrendModule(controller: controller)),
        const SliverToBoxAdapter(child: SizedBox(height: 92)),
      ],
    );
  }
}

class _DesktopHorizon extends StatelessWidget {
  const _DesktopHorizon({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _Panel(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _Header(controller: controller),
                _CalendarRibbon(controller: controller),
                const SizedBox(height: 14),
                _ConcentricDashboard(controller: controller, size: 330),
                const SizedBox(height: 16),
                _TrendModule(controller: controller),
              ],
            ),
          ),
        ),
        Expanded(
          child: _Panel(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: controller.day!.tasks.length + 1,
              itemBuilder: (context, index) {
                if (index == 0) return _SectionTitle('Daily Micro-Goals');
                final taskIndex = index - 1;
                final task = controller.day!.tasks[taskIndex];
                return _TaskTile(
                  task: task,
                  onDismissed: () => controller.removeTask(taskIndex),
                  onCompleted: (value) =>
                      controller.updateTask(taskIndex, completed: value),
                  onTime: (value) =>
                      controller.updateTask(taskIndex, onTime: value),
                  onHours: (value) =>
                      controller.updateTask(taskIndex, actualHours: value),
                );
              },
            ),
          ),
        ),
        Expanded(
          child: _Panel(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _BacklogBox(controller: controller),
                _ErrorConsole(controller: controller),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _DashboardDelegate extends SliverPersistentHeaderDelegate {
  const _DashboardDelegate({required this.controller, required this.compact});

  final ApexController controller;
  final bool compact;

  @override
  double get minExtent => compact ? 268 : 360;

  @override
  double get maxExtent => minExtent;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppColors.canvas,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      child: Column(
        children: [
          _Header(controller: controller),
          const SizedBox(height: 8),
          Expanded(
            child: GestureDetector(
              onTap: () => _showMetricBreakdown(context, controller),
              child: _ConcentricDashboard(controller: controller, size: 178),
            ),
          ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _DashboardDelegate oldDelegate) => true;
}

class _Header extends StatelessWidget {
  const _Header({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('JEE Apex Tracker',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 2),
              Text(
                DateFormat('EEE, d MMM yyyy').format(controller.selectedDate),
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: AppColors.muted),
              ),
            ],
          ),
        ),
        DropdownButton<TargetProfile>(
          value: controller.profile,
          dropdownColor: AppColors.surface,
          underline: const SizedBox.shrink(),
          items: TargetProfile.values
              .map(
                (profile) => DropdownMenuItem(
                  value: profile,
                  child: Text(profile.label),
                ),
              )
              .toList(),
          onChanged: (profile) {
            if (profile != null) controller.changeProfile(profile);
          },
        ),
      ],
    );
  }
}

class _ConcentricDashboard extends StatelessWidget {
  const _ConcentricDashboard({required this.controller, required this.size});

  final ApexController controller;
  final double size;

  @override
  Widget build(BuildContext context) {
    final metrics = controller.telemetry!;
    return Center(
      child: SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _ConcentricPainter(
            values: [
              metrics.effort,
              metrics.productivity,
              metrics.punctuality,
              metrics.revision,
              metrics.selection,
            ],
            colors: const [
              AppColors.physics,
              AppColors.chemistry,
              AppColors.mathematics,
              AppColors.analytics,
              AppColors.selection,
            ],
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${(metrics.selection * 100).round()}%',
                  style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                ),
                SizedBox(
                  width: size * 0.55,
                  child: Text(
                    controller.profile.selectionLabel,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.muted,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ConcentricPainter extends CustomPainter {
  const _ConcentricPainter({required this.values, required this.colors});

  final List<double> values;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final shortest = size.shortestSide;
    for (var i = 0; i < values.length; i++) {
      final radius = shortest / 2 - 12 - (i * 16);
      final stroke = i == values.length - 1 ? 10.0 : 8.0;
      final rect = Rect.fromCircle(center: center, radius: radius);
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = AppColors.border
          ..style = PaintingStyle.stroke
          ..strokeWidth = stroke,
      );
      canvas.drawArc(
        rect,
        -math.pi / 2,
        math.pi * 2 * values[i].clamp(0, 1).toDouble(),
        false,
        Paint()
          ..color = colors[i]
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.4)
          ..strokeWidth = stroke,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ConcentricPainter oldDelegate) => true;
}

class _CalendarRibbon extends StatelessWidget {
  const _CalendarRibbon({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    final selected = controller.selectedDate;
    final start = selected.subtract(Duration(days: selected.weekday - 1));
    final days = List.generate(7, (index) => start.add(Duration(days: index)));
    return SizedBox(
      height: 74,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemBuilder: (context, index) {
          final date = days[index];
          final active = DateUtils.isSameDay(date, selected);
          return InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => controller.loadDate(date),
            child: Container(
              width: 58,
              decoration: BoxDecoration(
                color: active ? AppColors.physics : AppColors.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(DateFormat.E().format(date).toUpperCase(),
                      style: const TextStyle(fontSize: 11)),
                  const SizedBox(height: 4),
                  Text(
                    DateFormat.d().format(date),
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemCount: days.length,
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  const _TaskTile({
    required this.task,
    required this.onDismissed,
    required this.onCompleted,
    required this.onTime,
    required this.onHours,
  });

  final TaskItem task;
  final VoidCallback onDismissed;
  final ValueChanged<bool> onCompleted;
  final ValueChanged<bool> onTime;
  final ValueChanged<double> onHours;

  @override
  Widget build(BuildContext context) {
    final accent = _subjectColor(task.subject);
    return Dismissible(
      key: ValueKey('${task.title}_${task.subject}_${task.targetHours}'),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDismissed(),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 18),
        color: AppColors.danger,
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        padding: const EdgeInsets.all(12),
        decoration: _boxDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(width: 5, height: 42, color: accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(task.title,
                          style: Theme.of(context).textTheme.titleMedium),
                      Text(
                        '${task.subject} • Target ${task.targetHours.toStringAsFixed(2)}h',
                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(color: AppColors.muted),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 76,
                  child: TextFormField(
                    initialValue: task.actualHours.toStringAsFixed(1),
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (value) =>
                        onHours(double.tryParse(value) ?? task.actualHours),
                    decoration: const InputDecoration(
                      isDense: true,
                      suffixText: 'h',
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                FilterChip(
                  label: const Text('Completed'),
                  selected: task.isCompleted,
                  selectedColor: accent.withOpacity(0.28),
                  onSelected: onCompleted,
                ),
                FilterChip(
                  label: const Text('On-Time'),
                  selected: task.isCompleted && task.isOnTime,
                  selectedColor: AppColors.chemistry.withOpacity(0.28),
                  onSelected: task.isCompleted ? onTime : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BacklogBox extends StatelessWidget {
  const _BacklogBox({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    final input = TextEditingController();
    final items = controller.day!.backlogItems;
    return _Box(
      title: 'Backlog Box',
      icon: Icons.pending_actions,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: input,
                  decoration:
                      const InputDecoration(hintText: 'Add backlog gap...'),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: () => controller.addBacklog(input.text),
                icon: const Icon(Icons.add),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (items.isEmpty)
            const _EmptyLine('No active backlog. Keep it clean.'),
          for (final item in items)
            _BacklogLine(
              item: item,
              onTap: () => controller.toggleBacklog(item.uid),
            ),
        ],
      ),
    );
  }
}

class _BacklogLine extends StatelessWidget {
  const _BacklogLine({required this.item, required this.onTap});

  final BacklogItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final elapsed = DateTime.now().difference(item.originDate);
    final remaining = 24 - elapsed.inHours;
    final expired = remaining < 0 && !item.isCompleted;
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      onTap: onTap,
      leading: Icon(
        item.isCompleted ? Icons.check_circle : Icons.radio_button_unchecked,
        color: item.isCompleted
            ? AppColors.chemistry
            : expired
                ? AppColors.danger
                : AppColors.mathematics,
      ),
      title: Text(item.title),
      subtitle: Text(
        expired ? 'Expired 24h window' : '$remaining hours left',
        style: TextStyle(color: expired ? AppColors.danger : AppColors.muted),
      ),
    );
  }
}

class _ErrorConsole extends StatefulWidget {
  const _ErrorConsole({required this.controller});

  final ApexController controller;

  @override
  State<_ErrorConsole> createState() => _ErrorConsoleState();
}

class _ErrorConsoleState extends State<_ErrorConsole> {
  final _input = TextEditingController();
  final _tags = <String>{};
  final _availableTags = const [
    'Silly Mistake',
    'Conceptual Error',
    'Time Management',
    'Physics',
    'Chemistry',
    'Maths',
  ];

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _Box(
      title: 'Error Log Black Box',
      icon: Icons.terminal,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final tag in _availableTags)
                FilterChip(
                  label: Text(tag),
                  selected: _tags.contains(tag),
                  onSelected: (value) {
                    setState(() {
                      value ? _tags.add(tag) : _tags.remove(tag);
                    });
                  },
                ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _input,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              prefixText: '> ',
              hintText: 'Log the mistake or question...',
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: () {
                widget.controller.addErrorLog(_input.text, _tags.toList());
                _input.clear();
                setState(_tags.clear);
              },
              icon: const Icon(Icons.save),
              label: const Text('Log'),
            ),
          ),
          const Divider(),
          for (final log in widget.controller.day!.errorLogs.reversed.take(5))
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text(log.description),
              subtitle: Text(log.tags.join(' • ')),
            ),
          _MentalClarity(controller: widget.controller),
          const SizedBox(height: 8),
          Text(
            widget.controller.day!.dailySummaryText,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppColors.text,
                  fontWeight: FontWeight.w700,
                ),
          ),
        ],
      ),
    );
  }
}

class _MentalClarity extends StatelessWidget {
  const _MentalClarity({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 0, label: Text('Overwhelmed')),
          ButtonSegment(value: 1, label: Text('Balanced')),
          ButtonSegment(value: 2, label: Text('Unstoppable')),
        ],
        selected: {controller.day!.mentalClarity.clamp(0, 2).toInt()},
        onSelectionChanged: (value) => controller.setMentalClarity(value.first),
      ),
    );
  }
}

class _TrendModule extends StatelessWidget {
  const _TrendModule({required this.controller});

  final ApexController controller;

  @override
  Widget build(BuildContext context) {
    return _Box(
      title: '7-Day / 30-Day Analytics',
      icon: Icons.show_chart,
      child: Column(
        children: [
          SizedBox(
            height: 160,
            child: CustomPaint(
              painter: _TrendPainter(points: controller.sevenDayHistory),
              child: const SizedBox.expand(),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 36,
            child: CustomPaint(
              painter: _SubjectBarPainter(points: controller.sevenDayHistory),
              child: const SizedBox.expand(),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrendPainter extends CustomPainter {
  const _TrendPainter({required this.points});

  final List<HistoricalPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.border
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    _drawLine(canvas, size, points.map((p) => p.selection).toList(),
        AppColors.analytics, false);
    _drawLine(canvas, size, points.map((p) => p.punctuality).toList(),
        AppColors.physics, true);
  }

  void _drawLine(
    Canvas canvas,
    Size size,
    List<double> values,
    Color color,
    bool dotted,
  ) {
    if (values.length < 2) return;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = size.height - (size.height * values[i].clamp(0, 1).toDouble());
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _TrendPainter oldDelegate) => true;
}

class _SubjectBarPainter extends CustomPainter {
  const _SubjectBarPainter({required this.points});

  final List<HistoricalPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final totals = <String, double>{};
    for (final point in points) {
      point.subjectHours.forEach((subject, hours) {
        totals.update(subject, (value) => value + hours, ifAbsent: () => hours);
      });
    }
    final total = totals.values.fold<double>(0, (sum, value) => sum + value);
    var dx = 0.0;
    for (final entry in totals.entries) {
      final width = total == 0 ? 0.0 : size.width * (entry.value / total);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(dx, 0, width, size.height),
          const Radius.circular(6),
        ),
        Paint()..color = _subjectColor(entry.key),
      );
      dx += width;
    }
    if (total == 0) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Offset.zero & size,
          const Radius.circular(6),
        ),
        Paint()..color = AppColors.border,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _SubjectBarPainter oldDelegate) => true;
}

class _Box extends StatelessWidget {
  const _Box({required this.title, required this.icon, required this.child});

  final String title;
  final IconData icon;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      padding: const EdgeInsets.all(12),
      decoration: _boxDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppColors.analytics),
              const SizedBox(width: 8),
              Text(title, style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        border: Border(right: BorderSide(color: AppColors.border)),
      ),
      child: child,
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Text(title, style: Theme.of(context).textTheme.titleLarge),
    );
  }
}

class _EmptyLine extends StatelessWidget {
  const _EmptyLine(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(text, style: const TextStyle(color: AppColors.muted)),
    );
  }
}

BoxDecoration _boxDecoration() {
  return BoxDecoration(
    color: AppColors.surface,
    borderRadius: BorderRadius.circular(8),
    border: Border.all(color: AppColors.border),
  );
}

Color _subjectColor(String subject) {
  return switch (subject) {
    'Physics' => AppColors.physics,
    'Chemistry' => AppColors.chemistry,
    'Mathematics' || 'Biology' => AppColors.mathematics,
    'Analytics' => AppColors.analytics,
    _ => AppColors.selection,
  };
}

void _showMetricBreakdown(BuildContext context, ApexController controller) {
  final metrics = controller.telemetry!;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.surface,
    showDragHandle: true,
    builder: (context) => Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _metricRow('Effort Index', metrics.effort, AppColors.physics),
          _metricRow('Productivity Meter', metrics.productivity, AppColors.chemistry),
          _metricRow('Punctuality Meter', metrics.punctuality, AppColors.mathematics),
          _metricRow('Revision Meter', metrics.revision, AppColors.analytics),
          _metricRow(controller.profile.selectionLabel, metrics.selection,
              AppColors.selection),
        ],
      ),
    ),
  );
}

Widget _metricRow(String label, double value, Color color) {
  return ListTile(
    contentPadding: EdgeInsets.zero,
    leading: Icon(Icons.circle, color: color, size: 14),
    title: Text(label),
    trailing: Text('${(value * 100).round()}%'),
  );
}

void _showAddTaskSheet(BuildContext context, ApexController controller) {
  final title = TextEditingController();
  final hours = TextEditingController(text: '1.0');
  var subject = 'Custom';
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    showDragHandle: true,
    builder: (context) => StatefulBuilder(
      builder: (context, setState) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          10,
          16,
          16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: title,
              decoration: const InputDecoration(hintText: 'Custom task title'),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: subject,
              items: const [
                'Physics',
                'Chemistry',
                'Mathematics',
                'Biology',
                'Analytics',
                'Custom',
              ].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (value) => setState(() => subject = value ?? subject),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: hours,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(hintText: 'Target hours'),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () {
                controller.addCustomTask(
                  title.text,
                  subject,
                  double.tryParse(hours.text) ?? 1.0,
                );
                Navigator.pop(context);
              },
              icon: const Icon(Icons.add),
              label: const Text('Add Task'),
            ),
          ],
        ),
      ),
    ),
  );
}
